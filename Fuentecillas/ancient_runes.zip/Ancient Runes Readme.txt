Ancient Runes - Font by ModBlackmoon. 
Version 1.1 from July 03, 2015

INFO: 
Incl. English, European letters and Numbers.
Kind of nordic font, or my vision of font based on rune shapes. Probably one of the few runic fonts which include the 'true nordic' symbols like @ or dollar sign:))

LICENSE: 
Freeware. No modify.

WEB: 
modblackmoon.com
facebook.com/ModBlackmoon.Art